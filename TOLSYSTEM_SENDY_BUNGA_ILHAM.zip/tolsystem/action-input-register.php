<?php

    require "koneksidb.php";
    

    if ($_POST['Submit'] == "Submit") {
        $nama                = $_POST['nama'];
        $username            = $_POST['username'];
        $password            = $_POST['password'];
    
      
        //Masukan data ke Table
        $input = "INSERT INTO tb_user (nama, username, password) VALUES ('" . $nama . "', '" . $username . "','" . $password . "')";
        $koneksi->query($input);
        

        header("Location: tambahuser.php?pesan=berhasil");
    }

?>