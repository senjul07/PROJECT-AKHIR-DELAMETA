<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/php; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Delameta Bilano | Tol System</title>

    <!-- Bootstrap -->
    <link href="vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- Animate.css -->
    <link href="vendors/animate.css/animate.min.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="login">
  
  <?php 
                if(isset($_GET['pesan'])){
                    if($_GET['pesan'] == "gagal"){
                        echo "<script type='text/javascript'>alert('Login gagal! username dan password salah!');</script>";
                    }else if($_GET['pesan'] == "logout"){
                        echo "<script type='text/javascript'>alert('Anda telah berhasil logout!');</script>";
                    }else if($_GET['pesan'] == "belum_login"){
                        echo "<script type='text/javascript'>alert('Anda harus login terlebih dahulu!');</script>";
                    }
                }
            ?>
  
    <div>
      <div class="login_wrapper">
        <div class="animate form login_form">
        <h1><img src="images/img.jpg" alt="..." class="img-thumbnail"></h1>
          <section class="login_content">
            <form class="box" action="cek-login.php" method="post" onSubmit="return validasi()">
              <h1>Login</h1>
              <br>
                <input type="text" id="username" name="username" class="form-control" placeholder="Masukan Username" autocomplete="off">
                <input type="password" id="password" name="password" class="form-control" placeholder="Masukan Password" autocomplete="off">
                <a></a>
                <input type="submit" class="btn btn-default submit" value="Masuk">
                <a></a>
                
                <div>
                   <h1><i class="fa fa-dekstop"></i></i></h1>
                   <h1><i class="fa fa-github-alt">  | Sendy |  <i class="fa fa-github-alt"></i></i></h1>
                   <h1><i class="fa fa-paw">  | Bunga |  <i class="fa fa-paw"></i></i></h1>
                   <h1><i class="fa fa-drupal">  | Ilham |  <i class="fa fa-drupal"></i></i></h1>
                  <p>©2016 All Rights Reserved. DELAMETA BILANO. Privacy and Terms</p>
                </div>
              </div>
            </form>
          </section>
        </div>
      </div>
    </div>
  </body>
  
  <script type="text/javascript">
            function validasi() {
                var username = document.getElementById("username").value;
                var password = document.getElementById("password").value;		
                if (username != "" && password!="") {
                    return true;
                }else{
                    alert('Username dan Password harus di isi !');
                    return false;
                }
            }
        
        </script>
  
</html>
