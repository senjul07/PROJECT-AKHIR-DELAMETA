<?php

    require "koneksidb.php";
    date_default_timezone_set('Asia/Jakarta');
    $tgl=date("Y-m-d G:i:s");

    if ($_POST['Submit'] == "Submit") {
        $ambilrfid          = $_POST['rfid'];
        $saldo              = $_POST['saldo'];
    
    //MENGAMBIL DATA Nama
    $nama = query("SELECT * FROM tb_daftarrfid WHERE rfid= '$ambilrfid'" )[0];
    $nama1 = $nama['nama'];
    
    //MENGAMBIL DATA Saldo RFID
    $tbtol1 = query("SELECT * FROM tb_daftarrfid WHERE rfid= '$ambilrfid'" )[0];
    $bayar1 = $tbtol1['saldo'];

    //MENGAMBIL DATA HARGA TOL
	$tbtol = query("SELECT * FROM tb_tol WHERE namatol= '$ambillokasi'" )[0];
    $bayar = $tbtol['tarif'];

      //MENGAMBIL DATA RFID
      $datarfid = mysqli_query($koneksi, "SELECT * FROM tb_daftarrfid WHERE rfid = '$ambilrfid'");
      $rowrfid  = mysqli_fetch_array($datarfid);
      $tambahsaldo = $rowrfid['saldo'] + $saldo;
      
        //Masukan data ke Table
        $sql = "UPDATE tb_daftarrfid SET saldo = '$tambahsaldo' WHERE rfid = '$ambilrfid'";
        $koneksi->query($sql);

        //Masukkan data ke Table riwayat topup
        //INSERT PADA TABEL tb_riwayattopup  	
        $input = "INSERT INTO tb_riwayattopup (tanggal, rfid, nama, jumlahtopup, saldoakhir) VALUES ('" . $tgl . "', '" . $ambilrfid . "', '" . $nama1 . "', '" . $saldo . "','" . $tambahsaldo . "')";
        $koneksi->query($input);
        

        header("Location: tablesriwayat.php?pesan=berhasil");
    }

?>