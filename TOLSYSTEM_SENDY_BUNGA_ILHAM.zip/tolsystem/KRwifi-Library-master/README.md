# KRwifi-Library
KRwifi adalah Library Arduino yang mempermudah untuk memprogram Kelas Robot WiFi Module dan Kelas Robot WiFi Shield.

# Update
Menambahkan Fungsi POST, ada contoh koding pada Examples untuk mengirim data ke Thingspeak
