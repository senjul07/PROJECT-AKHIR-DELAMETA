<?php

    require "koneksidb.php";

    if ($_POST['Submit'] == "Submit") {
        $pintutol          = $_POST['namatol'];
        $bayar             = $_POST['bayar'];
        $alamat            = $_POST['alamat'];

        //Masukan data ke Table
        $input = "INSERT INTO tb_tol (namatol, tarif, alamat) VALUES ('" . $pintutol . "', '" . $bayar . "','" . $alamat . "')";
        $koneksi->query($input);

        header("Location: tambahtol.php?pesan=berhasil");
    }

?>