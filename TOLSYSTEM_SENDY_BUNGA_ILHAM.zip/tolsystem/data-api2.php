<?php 
   require "koneksidb.php";

   $ambilrfid	   = $_GET["rfid2"];
   $ambillokasi	 = $_GET["namatol2"];
   $tgl=date("Y-m-d h:i:s");

   	  	// $data = query("SELECT * FROM tabel_monitoring")[0];

           
    //MENGAMBIL DATA Nama
    $nama = query("SELECT * FROM tb_daftarrfid WHERE rfid= '$ambilrfid'" )[0];
    $nama1 = $nama['nama'];
    
    //MENGAMBIL DATA Alamat
    $alamat = query("SELECT * FROM tb_daftarrfid WHERE rfid= '$ambilrfid'" )[0];
    $alamat1 = $alamat['alamat'];
    
    //MENGAMBIL DATA Telepon
    $telepon = query("SELECT * FROM tb_daftarrfid WHERE rfid= '$ambilrfid'" )[0];
    $telepon1 = $telepon['telepon'];
    
    //MENGAMBIL DATA Saldo RFID
    $tbtol1 = query("SELECT * FROM tb_daftarrfid WHERE rfid= '$ambilrfid'" )[0];
    $bayar1 = $tbtol1['saldo'];

    //MENGAMBIL DATA HARGA TOL GOLONGAN 1
	  $tbtol = query("SELECT * FROM tb_tol WHERE namatol= '$ambillokasi'" )[0];
    $bayar = $tbtol['tarifa'];
    
    //MENGAMBIL DATA HARGA TOL GOLONGAN 2
	  $tbtol2 = query("SELECT * FROM tb_tol WHERE namatol= '$ambillokasi'" )[0];
    $bayar2 = $tbtol2['tarifb'];
	
	//MENGAMBIL DATA CEK SALDO
	  $ceksaldo = query("SELECT * FROM tb_monitoring WHERE tb_daftarrfid= '$ambilrfid'" )[0];
    $ambilceksaldo = $ceksaldo['ceksaldo'];
    
    
    //KETIKA KARTU TIDAK TERDAFTAR
    //=============================================================================================================================
    if($nama1 == ""){
      
            $ambilceksaldo = "KARTU TIDAK TERDAFTAR!";
            
            //UPDATE DATA REALTIME PADA TABEL tb_monitoring
        		$sql      = "UPDATE tb_monitoring SET tanggal	= '$tgl', rfid	= '$ambilrfid', namatol = '$ambillokasi', nama = '$nama1', ceksaldo = '$ambilceksaldo', saldo = '$bayar1'";
        		$koneksi->query($sql);
           
           //MENJADIKAN JSON DATA
        		//$response = query("SELECT * FROM tb_monitoring")[0];
           
              $response['nama']    = "0";
              $result = json_encode($response);
               	echo $result;
           
    }
    //KETIKA KARTU TERDAFTAR DAN SALDO TIDAK MENCUKUPI
    //========================================================================================================================================
    else if($bayar1 <= $bayar){ 

      
      $ambilceksaldo="SALDO TIDAK MENCUKUPI!";
    
     
            
            //UPDATE DATA REALTIME PADA TABEL tb_monitoring
        		$sql      = "UPDATE tb_monitoring SET tanggal	= '$tgl', rfid	= '$ambilrfid', namatol = '$ambillokasi', nama = '$nama1', ceksaldo = '$ambilceksaldo', saldo = '$bayar1',tarif = '$bayar'";
        		$koneksi->query($sql);
           
           //MENJADIKAN JSON DATA
        		//$response = query("SELECT * FROM tb_monitoring")[0];
           
              $response['nama'] = "1";
              $response['saldoawal'] = "$bayar1";
              $response['tarifa'] = "$bayar";
              $response['saldoakhir'] = "$total";
                $result = json_encode($response);
               
             	echo $result;
    
      }
      //KETIKA KARTU TERDAFTAR DAN SALDO CUKUP
      //===============================================================================================================================================
      else{
    
           $ambilceksaldo="SUCCESS!";
           $golA = "GOLONGAN I";
    
            $total = $bayar1 - $bayar;
        			
        		//INSERT PADA TABEL tb_save  	
        		$sqlsave = "INSERT INTO tb_simpan (tanggal, rfid, nama, alamat, telepon, saldoawal, bayar, saldoakhir, masuktol) VALUES ('" . $tgl . "', '" . $ambilrfid . "', '" . $nama1 . "', '" . $alamat1 . "', '" . $telepon1 . "', '" . $bayar1 . "', '" . $bayar . "', '" . $total . "', '" . $ambillokasi . "')";
        		$koneksi->query($sqlsave);
           
            //UPDATE DATA SALDO PADA TABEL tb_daftarrfid
           	$sql      = "UPDATE tb_daftarrfid SET saldo	= '$total' WHERE rfid= '$ambilrfid'";
            $koneksi->query($sql);
            
            //UPDATE DATA REALTIME PADA TABEL tb_monitoring
        		$sql      = "UPDATE tb_monitoring SET tanggal	= '$tgl', rfid	= '$ambilrfid', namatol = '$ambillokasi', nama = '$nama1', tarif = '$bayar', ceksaldo = '$ambilceksaldo', saldo = '$total'";
        		$koneksi->query($sql);
           
           //MENJADIKAN JSON DATA
        		//$response = query("SELECT * FROM tb_monitoring")[0];
          
              $response['nama'] = "2";
              $response['saldoawal'] = "$bayar1";
              $response['tarifb'] = "$bayar";
              $response['saldoakhir'] = "$total";
                $result = json_encode($response);
               
             	echo $result;
				}

 ?>