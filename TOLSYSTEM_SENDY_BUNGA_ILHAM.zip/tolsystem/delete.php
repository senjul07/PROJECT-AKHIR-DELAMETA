<?php
      require 'koneksidb.php';
      $query = "SELECT * FROM tb_daftarrfid";
      $data1 = $koneksi->prepare($query);
      $data1->execute();
      $res1 = $data1->get_result();
 
      if($res1->num_rows > 0){
      
      $koneksi->close();
// mengalihkan ke halaman index.php
header("location:hapusdatarfid.php?pesan=berhasil");
?>
