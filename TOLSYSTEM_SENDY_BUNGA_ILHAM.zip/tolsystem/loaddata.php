<?php 

   //Simpan dengan nama file panel.php
     require "koneksidb.php";
     $data    = query("SELECT * FROM tb_monitoring")[0];


 ?>



<!DOCTYPE html>
 <html>
 <head>
 	<title>	</title>
 </head>
 <body>

        <div class="row">
        
          <div class="row tile_count">
            <div class="col-md-4 col-sm-6 col-xs-8 tile_stats_count">
              <span class="count_top"><i class="fa fa-clock-o"></i> TIME</span>
              <h1 class="mb-1"><?=$data["tanggal"];?></h1>
              <span class="count_bottom"><i class="green"><i class="fa fa-sort-asc"></i></i><span class="ml-1">update</span>
            </div>
             <div class="col-md-4 col-sm-6 col-xs-8 tile_stats_count">
              <span class="count_top"><i class="fa fa-user"></i> NAMA</span>
              <h1 class="mb-1"><?=$data["nama"];?></h1>
              <span class="count_bottom"><i class="green"><i class="fa fa-sort-asc"></i></i><span class="ml-1">update</span>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-8 tile_stats_count">
              <span class="count_top"><i class="fa fa-credit-card"></i> RFID</span>
              <h1 class="mb-1"><?=$data["rfid"];?></h1>
              <span class="count_bottom"><i class="green"><i class="fa fa-sort-asc"></i></i><span class="ml-1">update</span>
            </div>
			      <div class="col-md-4 col-sm-6 col-xs-8 tile_stats_count">
              <span class="count_top"><i class="fa fa-road"></i> PINTU TOL</span>
              <h1 class="mb-1"><?=$data["namatol"];?></h1>
              <span class="count_bottom"><i class="green"><i class="fa fa-sort-asc"></i></i><span class="ml-1">update</span>
            </div>
             <div class="col-md-4 col-sm-6 col-xs-8 tile_stats_count">
              <span class="count_top"><i class="fa fa-usd"></i> TARIF</span>
              <h1 class="mb-1"><?=$data["tarif"];?></h1>
              <span class="count_bottom"><i class="green"><i class="fa fa-sort-asc"></i></i><span class="ml-1">update</span>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-8 tile_stats_count">
              <span class="count_top"><i class="fa fa-money"></i> SALDO ANDA</span>
              <h1 class="mb-1"><?=$data["saldo"];?></h1>
              <span class="count_bottom"><i class="green"><i class="fa fa-sort-asc"></i></i><span class="ml-1">update</span>
            </div>
             <div class="col-md-6 col-sm-8 col-xs-10 tile_stats_count">
              <span class="count_top"><i class="fa fa-info"></i> STATUS</span>
              <h1 class="mb-1"><?=$data["ceksaldo"];?></h1>
              <span class="count_bottom"><i class="green"><i class="fa fa-sort-asc"></i></i><span class="ml-1">update</span>
            </div>
            <div class="col-md-6 col-sm-8 col-xs-10 tile_stats_count">
              <span class="count_top"><i class="fa fa-automobile"></i> GOLONGAN</span>
              <h1 class="mb-1"><?=$data["golongan"];?></h1>
              <span class="count_bottom"><i class="green"><i class="fa fa-sort-asc"></i></i><span class="ml-1">update</span>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-8 tile_stats_count">
              <span class="count_top"></span>
              <div class="count green"></div>
              <span class="count_bottom"><i class="green"></i></i></span>
            </div>
          </div>
</div>	

 </body>
 </html>