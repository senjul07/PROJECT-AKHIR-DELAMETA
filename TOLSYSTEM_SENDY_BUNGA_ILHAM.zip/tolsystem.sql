-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 23, 2021 at 05:53 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tolsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_daftarrfid`
--

CREATE TABLE `tb_daftarrfid` (
  `no` int(100) NOT NULL,
  `rfid` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `telepon` varchar(100) NOT NULL,
  `saldo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_daftarrfid`
--

INSERT INTO `tb_daftarrfid` (`no`, `rfid`, `nama`, `alamat`, `telepon`, `saldo`) VALUES
(15, 'AB51DC9', 'Ilham Destyo', 'Jalan Meruya Hilir', '085725671212', '4000'),
(16, 'E75B9F19', 'Bunga Sridevi', 'Jalan Kayumanis', '085781427123', '2801000'),
(18, 'F3B71ED', 'pak iwan', 'jakarta', '086789335', '5000');

-- --------------------------------------------------------

--
-- Table structure for table `tb_monitoring`
--

CREATE TABLE `tb_monitoring` (
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `rfid` varchar(100) NOT NULL,
  `namatol` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `tarif` varchar(100) NOT NULL,
  `ceksaldo` varchar(100) NOT NULL,
  `saldo` varchar(100) NOT NULL,
  `golongan` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_monitoring`
--

INSERT INTO `tb_monitoring` (`tanggal`, `rfid`, `namatol`, `nama`, `tarif`, `ceksaldo`, `saldo`, `golongan`) VALUES
('2021-12-21 22:37:37', 'F3B71ED', 'bandung', 'pak iwan', '6000', 'SALDO TIDAK MENCUKUPI!', '5000', 'GOLONGAN II');

-- --------------------------------------------------------

--
-- Table structure for table `tb_riwayattopup`
--

CREATE TABLE `tb_riwayattopup` (
  `no` int(11) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `rfid` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `jumlahtopup` varchar(100) NOT NULL,
  `saldoakhir` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_riwayattopup`
--

INSERT INTO `tb_riwayattopup` (`no`, `tanggal`, `rfid`, `nama`, `jumlahtopup`, `saldoakhir`) VALUES
(12, '2021-12-22 00:33:51', 'E75B9F19', 'Bunga Sridevi', '1000000', '1889000'),
(13, '2021-12-22 00:35:35', 'E75B9F19', 'Bunga Sridevi', '1000000', '2889000');

-- --------------------------------------------------------

--
-- Table structure for table `tb_simpan`
--

CREATE TABLE `tb_simpan` (
  `no` int(100) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `rfid` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `telepon` varchar(100) NOT NULL,
  `saldoawal` varchar(100) NOT NULL,
  `bayar` varchar(100) NOT NULL,
  `saldoakhir` varchar(100) NOT NULL,
  `masuktol` varchar(100) NOT NULL,
  `golongan` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_simpan`
--

INSERT INTO `tb_simpan` (`no`, `tanggal`, `rfid`, `nama`, `alamat`, `telepon`, `saldoawal`, `bayar`, `saldoakhir`, `masuktol`, `golongan`) VALUES
(1390, '2021-12-21 18:36:26', 'E75B9F19', 'Bunga Sridevi', 'Jalan Kayumanis', '085781427123', '2889000', '6000', '2883000', 'bandung', 'GOLONGAN II'),
(1391, '2021-12-21 18:36:29', 'E75B9F19', 'Bunga Sridevi', 'Jalan Kayumanis', '085781427123', '2883000', '5000', '2878000', 'bandung', 'GOLONGAN I'),
(1392, '2021-12-21 18:39:21', 'E75B9F19', 'Bunga Sridevi', 'Jalan Kayumanis', '085781427123', '2878000', '5000', '2873000', 'bandung', 'GOLONGAN I'),
(1393, '2021-12-21 19:08:28', 'E75B9F19', 'Bunga Sridevi', 'Jalan Kayumanis', '085781427123', '2873000', '5000', '2868000', 'bandung', 'GOLONGAN I'),
(1394, '2021-12-21 19:11:46', 'E75B9F19', 'Bunga Sridevi', 'Jalan Kayumanis', '085781427123', '2868000', '6000', '2862000', 'bandung', 'GOLONGAN II'),
(1395, '2021-12-21 19:27:15', 'E75B9F19', 'Bunga Sridevi', 'Jalan Kayumanis', '085781427123', '2862000', '5000', '2857000', 'bandung', 'GOLONGAN I'),
(1396, '2021-12-21 19:28:01', 'E75B9F19', 'Bunga Sridevi', 'Jalan Kayumanis', '085781427123', '2857000', '6000', '2851000', 'bandung', 'GOLONGAN II'),
(1397, '2021-12-21 19:28:18', 'E75B9F19', 'Bunga Sridevi', 'Jalan Kayumanis', '085781427123', '2851000', '6000', '2845000', 'bandung', 'GOLONGAN II'),
(1398, '2021-12-21 19:28:44', 'E75B9F19', 'Bunga Sridevi', 'Jalan Kayumanis', '085781427123', '2845000', '5000', '2840000', 'bandung', 'GOLONGAN I'),
(1399, '2021-12-21 20:09:25', 'E75B9F19', 'Bunga Sridevi', 'Jalan Kayumanis', '085781427123', '2840000', '6000', '2834000', 'bandung', 'GOLONGAN II'),
(1400, '2021-12-21 20:12:35', 'E75B9F19', 'Bunga Sridevi', 'Jalan Kayumanis', '085781427123', '2834000', '6000', '2828000', 'bandung', 'GOLONGAN II'),
(1401, '2021-12-21 20:40:27', 'E75B9F19', 'Bunga Sridevi', 'Jalan Kayumanis', '085781427123', '2828000', '6000', '2822000', 'bandung', 'GOLONGAN II'),
(1402, '2021-12-21 20:40:48', 'E75B9F19', 'Bunga Sridevi', 'Jalan Kayumanis', '085781427123', '2822000', '6000', '2816000', 'bandung', 'GOLONGAN II'),
(1403, '2021-12-21 20:41:12', 'E75B9F19', 'Bunga Sridevi', 'Jalan Kayumanis', '085781427123', '2816000', '5000', '2811000', 'bandung', 'GOLONGAN I'),
(1404, '2021-12-21 22:32:27', 'E75B9F19', 'Bunga Sridevi', 'Jalan Kayumanis', '085781427123', '2811000', '5000', '2806000', 'bandung', 'GOLONGAN I'),
(1405, '2021-12-21 22:34:46', 'E75B9F19', 'Bunga Sridevi', 'Jalan Kayumanis', '085781427123', '2806000', '5000', '2801000', 'bandung', 'GOLONGAN I'),
(1406, '2021-12-21 22:37:13', 'F3B71ED', 'pak iwan', 'jakarta', '086789335', '10000', '5000', '5000', 'bandung', 'GOLONGAN I');

-- --------------------------------------------------------

--
-- Table structure for table `tb_tol`
--

CREATE TABLE `tb_tol` (
  `no` int(100) NOT NULL,
  `namatol` varchar(100) NOT NULL,
  `tarifa` varchar(100) NOT NULL,
  `tarifb` varchar(100) NOT NULL,
  `alamat` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_tol`
--

INSERT INTO `tb_tol` (`no`, `namatol`, `tarifa`, `tarifb`, `alamat`) VALUES
(1, 'bandung', '5000', '6000', 'jalan bandung'),
(2, 'jakarta', '6000', '7000', 'jalan jakarta'),
(3, 'bogor', '4000', '5000', 'jalan bogor');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `no` int(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`no`, `nama`, `username`, `password`) VALUES
(6, 'Sendy Juliansyah', 'sendy', 'sendy'),
(9, 'Bunga Sridevi', 'bunga', 'bunga'),
(10, 'Ilham Destyo', 'ilham', 'ilham');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_daftarrfid`
--
ALTER TABLE `tb_daftarrfid`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `tb_riwayattopup`
--
ALTER TABLE `tb_riwayattopup`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `tb_simpan`
--
ALTER TABLE `tb_simpan`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `tb_tol`
--
ALTER TABLE `tb_tol`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_daftarrfid`
--
ALTER TABLE `tb_daftarrfid`
  MODIFY `no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `tb_riwayattopup`
--
ALTER TABLE `tb_riwayattopup`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tb_simpan`
--
ALTER TABLE `tb_simpan`
  MODIFY `no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1407;

--
-- AUTO_INCREMENT for table `tb_tol`
--
ALTER TABLE `tb_tol`
  MODIFY `no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
